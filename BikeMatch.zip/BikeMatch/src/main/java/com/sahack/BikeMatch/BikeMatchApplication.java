package com.sahack.BikeMatch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BikeMatchApplication {

	public static void main(String[] args) {
		SpringApplication.run(BikeMatchApplication.class, args);
	}

}
