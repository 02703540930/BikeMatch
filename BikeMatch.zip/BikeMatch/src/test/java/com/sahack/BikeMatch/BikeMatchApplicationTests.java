package com.sahack.BikeMatch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BikeMatchApplicationTests {

	@Test
	void contextLoads() {
	}

}
